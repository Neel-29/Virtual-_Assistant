from pathlib import Path
from shutil import rmtree

root = Path(__file__).parent.parent
pycache_folders = [
	root / "assistant" / "__pycache__"
]

for path in pycache_folders:
	rmtree(path)
